<?php
session_start();

// Redirect to login if the session doesn't exist
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}

// You can fetch additional student-related data from the database based on the logged-in user if needed

// Example: Fetching student's name from the database
$studentName = "John Doe"; // Replace this with actual data retrieval logic

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome, Student</title>
    <!-- Add your CSS links or styles here -->
</head>
<body>
    <h1>Welcome, <?php echo $studentName; ?>!</h1>
    <p>This is the student dashboard.</p>
    <a href="logout.php">Logout</a> <!-- A link to log out -->
    <!-- Add your HTML content specific to the student page here -->
</body>
</html>
