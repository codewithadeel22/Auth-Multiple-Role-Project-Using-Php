<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Links</title>
 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        
        .link-column {
            display: flex;
           flex-direction: column;
            gap: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            position: relative;
            top: 2rem;
            
        }
        .link-item {
            width: 12rem;
            text-align: center;
            padding: 5px;
            background-color: #f0f0f0;
            border-left: 1px solid #ccc; 
            border-right: 1px solid #ccc; 
            border-top: none; 
            border-bottom: none; 
            border-radius: 3px;
            transition: background-color 0.3s ease;
            text-decoration: none; 
            font-size: 1.2rem;
        }
        .link-item:hover {
            background-color: #e0e0e0;
        }
       
        
        .container{
            background-color: black;
            width: 18%;
            height: 22rem;
           position: relative;
           right: 35.2rem;
           
        }
        .admin-logo{
            width: 3rem;
            border: 1px solid white;
            border-radius: 3rem;
        }
        .pic-dash{
       display: flex;
       flex-direction: row;
        }

        .dash-text {
            animation: colorChange 1s infinite;
            position: relative;
            top:0.4rem;
            left:0.4rem;
        }
        @keyframes colorChange {
            0% { color: yellow; }
            30% { color: red; }
            50% { color: green; }
            60% { color: blue; }
            70% { color: white; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col"> 
                <div class="link-column" >
                    <div class="pic-dash">
                        <img src="ad.png" class="admin-logo"/>
                        <h3 class="dash-text">Dashboard</h3>
                    </div>
                    <a href="index.php" class="link-item">Admin</a>
                    <a href="index.php" class="link-item">Teacher</a>
                    <a href="index.php" class="link-item">Student</a>
                    <a href="signup.php" class="link-item">Register</a>
                </div>
            </div>
        </div>
    </div>

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
