<?php
session_start();

// Redirect to login if the session doesn't exist or if the role is not admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Fetch additional admin-related data from the database based on the logged-in user if needed

// Example: Fetching admin's name from the database
$adminName = "Admin"; // Replace this with actual data retrieval logic

// Retrieve the list of active users from your database or any other source where their status is tracked
// For demonstration purposes, let's create a sample array of logged-in users
$loggedInUsers = [
    ['username' => 'John', 'role' => 'student'],
    ['username' => 'Jane', 'role' => 'teacher'],
    ['username' => 'Alex', 'role' => 'student'],
    // Add more users if available
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome, Admin</title>
    <!-- Add your CSS links or styles here -->
</head>
<body>
    <h1>Welcome, <?php echo $adminName; ?>!</h1>
    <p>This is the admin dashboard.</p>
    <h2>Active Users</h2>
    <table>
        <thead>
            <tr>
                <th>Username</th>
                <th>Role</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($loggedInUsers as $user) : ?>
                <tr>
                    <td><?= $user['username']; ?></td>
                    <td><?= $user['role']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="logout.php">Logout</a> <!-- A link to log out -->
    <!-- Add your HTML content specific to the admin page here -->
</body>
</html>
