<?php
session_start();


if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit;
}



$teacherName = "Jane Smith"; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome, Teacher</title>
    <!-- Add your CSS links or styles here -->
</head>
<body>
    <h1>Welcome, <?php echo $teacherName; ?>!</h1>
    <p>This is the teacher dashboard.</p>
    <a href="logout.php">Logout</a> <!-- A link to log out -->
    <!-- Add your HTML content specific to the teacher page here -->
</body>
</html>
