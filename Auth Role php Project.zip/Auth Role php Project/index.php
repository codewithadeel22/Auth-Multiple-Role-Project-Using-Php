<?php
session_start();
$conn = new mysqli("localhost", "root", "", "multiuserpanel");
$msg = "";

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
   
    $usertype = $_POST['usertype'];

    $sql = "SELECT * FROM users WHERE username = ? AND password = ? AND usertype = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $usertype);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1) {
        while ($row = $result->fetch_assoc()) {
            echo "Retrieved Username: " . $row['username'] . "<br>"; 
            echo "Retrieved Role: " . $row['usertype'] . "<br>";
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['usertype'];

            if ($_SESSION['role'] == "student") {
                header("Location: student.php");
                exit;
            } else if ($_SESSION['role'] == "teacher") {
                header("Location: teacher.php");
                exit;
            } else if ($_SESSION['role'] == "admin") {
                header("Location: admin.php");
                exit;
            } else {
                $msg = "User is not authorized or role is not correctly set!";
            }
        }
    } else {
        $msg = "Username or Password is Incorrect!";
    }
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script>
        function showAlert(message) {
            alert(message);
        }
    </script>
    <style>
        /* Custom color scheme */
        body {
            background-color: #121212; /* Light black background */
            color: #fff; /* White text */
        }
        .login-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .form-bg {
            background-color: #1e1e1e; /* Darker background for form */
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
        }
        .form-control:focus {
            border-color: #86b7fe;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
       
    </style>
</head>
<body>
    <div class="container login-container">
        <form action="<?= $_SERVER['PHP_SELF']?>" method="post" class="w-50 p-4 form-bg">
            <h1 class="mb-4">Login</h1>
            <div class="mb-3">
    <label for="exampleInputUsername" class="form-label">Username</label>
    <input type="text" class="form-control" id="exampleInputUsername" name="username" aria-describedby="usernameHelp" placeholder="Enter Username">
    
</div>


            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password">
            </div>

            <div class="form-group lead mb-3">
                <label for="usertype">I'm a :</label>
                <div>
                    <input type="radio" name="usertype" value="student" class="custom-radio" required/>&nbsp;student |
                    <input type="radio" name="usertype" value="teacher" class="custom-radio" required/>&nbsp;teacher |
                    <input type="radio" name="usertype" value="admin" class="custom-radio" required/>&nbsp;admin 
                </div>
            </div>

            <button type="submit" class="btn btn-primary" name="login">Submit</button>
        </form>
        <p class="mt-3">Don't have an account? <a href="signup.php">Sign Up</a></p>
        <?php if ($msg !== "") : ?>
            <script>
                showAlert('<?= $msg ?>');
            </script>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>



